// const Username = document.getElementById('name');
// const email = document.getElementById('email');
// const phonenumber = document.getElementById('phonenumber');
// const password = document.getElementById('password');
// const confirmPass = document.getElementById('confirmPass');
// const formValue = [Username,email,phonenumber,password,confirmPass].value;

// formValue.map((item)=>{
//     console.log(item)
// })
//chưa làm xong


